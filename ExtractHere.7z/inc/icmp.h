/*
 * \file icmp.h
 * \brief header for icmp protocol
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __ICMP_H__
#define __ICMP_H__

#define ICMPSEQ_RANDOM 0x01
#define ICMPID_RANDOM 0x02
#define ICMPTIME_ORIG_RANDOM 0x04
#define ICMPTIME_SEND_RANDOM 0x08
#define ICMPTIME_RECV_RANDOM 0x10
#define ICMPHDR_SIZE sizeof (struct xicmphdr)

enum icmp_type_e
  {
    ECHO_REPLY = 0,
    DEST_UNREACHABLE = 3,
    SRC_QUENCH = 4,
    REDIRECT = 5,
    ECHO_REQUEST = 8,
    TIME_EXCEEDED = 11,
    PARAM_UNINTELLIGIBLE = 12,
    TIMESTAMP_REQUEST = 13,
    TIMESTAMP_REPLY = 14,
    INFO_REQUEST = 15,
    INFO_REPLY = 16,
    ADDR_MASK_REQUEST = 17,
    ADDR_MASK_REPLY = 18
  };

struct icmpopt_s
  {
    u8 type;
    u8 code;
    u8 seq;
    u8 id;
    u8 random;
    u32 router;
    u_char tcp :1,
           udp :1;
    struct ipopt_s ip;
    u8 proto;
    u8 totlen;
    union
      {
        struct addtcp_s
          {
            u16 psrc;
            u16 pdst;
            u32 seq;
          } tcp;
        struct addudp_s
          {
            u16 psrc;
            u16 pdst;
            u16 len;
            __sum16 check;
          } udp;
	struct time_s
	  {
	    u32 orig;
	    u32 recv;
	    u32 send;
	  } time;
      } t;
  };

/* this original structure */
struct xicmphdr {
  u8          type;
  u8          code;
  __sum16       checksum;
  union {
        struct {
                u16  id;
                u16  sequence;
        } echo;
        u32  gateway;
        struct {
                u16  unused;
                u16  mtu;
        } frag;
  } un;
};

void icmp_make_hdr (char *header);
void icmp_add_hdr_ip (char *add_ip);
void icmp_add_hdr_tcp (char *hdr);
void icmp_add_hdr_udp (char *hdr);
void icmp_set_timestamp (char *hdr);
char * icmp_get_name_type (int type);

#endif /* __ICMP_H__ */
