/*
 * \file socket.h
 * \brief header for socket
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __SOCKET_H__
#define __SOCKET_H__

#define SOCK_IN 0x01
#define SOCK_LL 0x02

struct socket_s
  {
    int fd;
    int sizepkt;
    union
      {
        struct sockaddr_in in;
#ifdef __OS_IS_LINUX
        struct sockaddr_ll ll;
#endif /* __OS_IS_LINUX */
      } s;
  };

struct sockopt_s
  {
    u_char sock_mode;
    void (*init_socket) (struct socket_s *, int);
    int (*send_packet) (struct socket_s *, char *, int);
  };

int create_new_socket (int domain, int type, int protocol);
void init_socket_in (struct socket_s *sock, int protocol);
void xsetsockopt (int socket);
int send_in (struct socket_s *s, char *packet, int size);

#ifdef __OS_IS_LINUX
void linux_eth_socket_open (struct socket_s *sock, int protocol);
void linux_eth_bind (struct socket_s *socket);
int linux_eth_send (struct socket_s *s, char *packet, int size);
#else /* __OS_IS_BSD */
void BSD_open_eth_device (struct socket_s *sock, int protocol);
int BSD_eth_send (struct socket_s *s, char *packet, int size);
#endif /* end test OS */

#endif /* __SOCKET_H__ */
