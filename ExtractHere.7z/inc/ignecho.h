/*
 * \file ignecho.h
 * \brief header for ignecho.c
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __IGNECHO_H__
#define __IGNECHO_H__

#define IGN_ECHO 0x08

#ifdef __OS_IS_LINUX
#define LINUX_FILE_IGN_ECHO "/proc/sys/net/ipv4/icmp_echo_ignore_all"
#endif /* __OS_IS_LINUX */

int ignore_echo (int mode);

#endif /* __IGNECHO_H__ */
