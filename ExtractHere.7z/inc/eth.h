/*
 * \file eth.h
 * \brief header for ethernet protocol
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __ETH_H__
#define __ETH_H__

#define ARPHDR_SIZE sizeof (struct arphdr_s)
#define ARPPKT_SIZE ETHHDR_SIZE + ARPHDR_SIZE
#define ETHHDR_SIZE sizeof (struct xethhdr)

#define MAC_BROADCAST "\xff\xff\xff\xff\xff\xff"
#define MAC_NOT_INIT "\x00\x00\x00\x00\x00\x00"
#define ARPHRD_ETHER 1

#ifndef ETH_ALEN
#define ETH_ALEN 6
#endif /* ETH_ALEN */

#ifndef ETH_P_ARP
#define ETH_P_ARP 0x0806
#endif /* ETH_P_ALL */

#ifndef ETH_P_IP
#define ETH_P_IP 0x800
#endif /* ETH_P_IP */

enum arp_type_e
  {
    ARPOP_REQUEST = 1,
    ARPOP_REPLY = 2,
    ARPOP_RREQUEST = 3,
    ARPOP_RREPLY = 4,
    ARPOP_InREQUEST = 8,
    ARPOP_InREPLY = 9,
    ARPOP_NAK = 10
  };

struct ethopt_s
  {
    u_char src[ETH_ALEN];
    u_char dst[ETH_ALEN];
  };

/* this original structure */
struct xethhdr {
        unsigned char   h_dest[ETH_ALEN];
        unsigned char   h_source[ETH_ALEN];
        u16          h_proto;
} __attribute__((packed));
/* end */

struct arpopt_s
  {
    u16 opcode;
    u_char sha[ETH_ALEN];
    u_char sip[4];
    u_char tha[ETH_ALEN];
    u_char tip[4];
  };

/* this original structure */
struct xarphdr
{
        u16 ar_hrd;
        u16 ar_pro;
        unsigned char ar_hln;
        unsigned char ar_pln;
        u16 ar_op;
};
/* end */

struct arphdr_s
  {
    struct xarphdr a;
    u_char ar_sha[ETH_ALEN];
    u_char ar_sip[4];
    u_char ar_tha[ETH_ALEN];
    u_char ar_tip[4];
} __attribute__ ((packed));

void ethernet_make_hdr (char *packet);
void set_mac_to_str (char *smac, u_char *umac);

#endif /* __ETH_H__ */
