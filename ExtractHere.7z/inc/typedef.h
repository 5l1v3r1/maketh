/*
 * \file typedef.h
 * \brief type variable
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__

#include "maketh.h"

typedef unsigned char u_char;
typedef unsigned int u_int;
typedef unsigned long u_long;
//typedef unsigned short u_short;

typedef uint16_t u16;
typedef uint32_t u32;
typedef uint8_t u8;
typedef uint16_t __sum16;


/**
 * tous sa a decaler dans un fichier protocol.h
 * et a include apres eth.h ??
 */
#ifndef ETH_P_ALL
#define ETH_P_ALL 0x0003
#endif

enum protocol_e
  {
    ARP = ETH_P_ALL,
    IP = IPPROTO_IPIP,
    TCP = IPPROTO_TCP,
    UDP = IPPROTO_UDP,
    ICMP = IPPROTO_ICMP,
    IGMP = IPPROTO_IGMP,
    UNKNOW = 255
 };
/* end comments */

enum timeout_mode_e
{ SEC = 0x40, USEC = 0x80 };

struct opt_s
  {
    int count;
    int lendata;
    useconds_t timeout;
    u8 protocol;
    u8 i_device;
    u16 mtu;
    int hdrsize;
    u16 psrc;
    u16 pdst;
    int off_ip;
    u8 option;
    char *data;
    char *target_orig;
    char devname[NETDEVICE_LEN];
    u_char random;
  };

struct stt_s
  {
    long send;
    long recv;
  };

#endif /* __TYPEDEF_H__ */
