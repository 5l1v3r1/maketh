/*
 * \file printpkt.h
 * \brief header for printpkt.c
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __PRINTPKT_H__
#define __PRINTPKT_H__

void print_ethernet (const char *pkt);
int print_ethernet_hexa (const char *pkt);
void print_arp (struct arphdr_s *arp);
void print_arp_hexa (struct arphdr_s *arp, int *newline);
void print_ip_verbose (const char *pkt, int offset, int size);
void print_ip (const char *pkt, int offset, int size);
void print_ip_hexa (const char *pkt, int offset, int *newline);
void print_icmp (const char *pkt);
void print_icmp_gateway (u32 ip_gateway);
void print_icmp_timestamp (const char *pkt);
void print_icmp_add_header (const char *pkt);
void print_icmp_hexa (const char *pkt, int size, int *newline);
void print_tcp (const char *pkt, int size);
void print_tcp_verbose (const char *pkt);
void print_tcp_hexa (const char *pkt, int *newline);

#endif /* __PRINTPKT_H__ */
