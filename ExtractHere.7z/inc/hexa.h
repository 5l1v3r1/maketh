/*
 * \file hexa.h
 * \brief header for hexa.c
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __HEXA_H__
#define __HEXA_H__

#define SIZE_TAB_HEXA(y) y / sizeof (struct print_hexa_index_s)

struct print_hexa_index_s
  {
    int nb_line;
    char *text;
  };

void print_hexa (size_t size, unsigned int octets, int *newline);
void print_new_line (int current);

#endif /* __HEXA_H__ */
