/*
 * \file addhdr.h
 * \brief add header for calcul checksum on TCP and UDP header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __ADDHDR_H__
#define __ADDHDR_H__

#define ADDHDR_SIZE sizeof (struct addhdr_s)

struct addhdr_s
  {
    u_long saddr;
    u_long daddr;
    char useless;
    u_char protocol;
    u_short length;
  };

#endif /* __ADDHDR_H__ */
