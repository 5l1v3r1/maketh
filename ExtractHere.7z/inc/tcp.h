/*
 * \file tcp.h
 * \brief header for tcp protocol
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __TCP_H__
#define __TCP_H__

/* get flags */
#define GET_NBIT(y, n) (y >> n) & 1

#define OFFSET_FLAGS 13
#define FLAG_SYN 0x01
#define FLAG_ACK 0x02
#define FLAG_RST 0x04
#define FLAG_FIN 0x08
#define FLAG_PSH 0x10
#define FLAG_URG 0x20
#define TCPOPT_TIMESTAMP 0x01
#define TCPOPT_MSS 0x02
#define TCPHDR_SIZE sizeof (struct xtcphdr)
#define TCPSEQ_RANDOM 0x01

struct tcpopt_s
  {
    u_char random;
    u8 doff;
    u32 seq;
    u32 ackseq;
    u_char flags;
    u16 windows;
    u16 ptr;
    u_char opt[12];
    __sum16 check;
    u8 lenhdr;
  };

/* this original structure */
struct xtcphdr {
        u16  source;
        u16  dest;
        u32  seq;
        u32  ack_seq;
#if defined(__PROC_IS_LITTLE_ENDIAN)
        u16   res1:4,
                doff:4,
                fin:1,
                syn:1,
                rst:1,
                psh:1,
                ack:1,
                urg:1,
                ece:1,
                cwr:1;
#elif defined(__PROC_IS_BIG_ENDIAN)
        u16   doff:4,
                res1:4,
                cwr:1,
                ece:1,
                urg:1,
                ack:1,
                psh:1,
                rst:1,
                syn:1,
                fin:1;
#else
#error  "Adjust your <asm/byteorder.h> defines"
#endif  
        u16  window;
        __sum16 check;
        u16  urg_ptr;
};

void tcp_make_hdr (char *packet);

#endif /* __TCP_H__ */
