/*
 * \file maketh.h
 * \brief all header config
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __MAKETH_H__
#define __MAKETH_H__

#include "config-system.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <fcntl.h>
#include <getopt.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdarg.h>

#ifdef __OS_IS_LINUX
#include <linux/netdevice.h>
#include <asm/byteorder.h>
#endif /* __OS_IS_LINUX */

#ifdef __OS_IS_BSD
#include <stdint.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <netinet/in.h>
#include <ifaddrs.h>
#include <fcntl.h>
#include <net/bpf.h>
#endif /* __OS_IS_BSD */

#include "config.h"
#include "typedef.h"

#include "eth.h"
#include "ip.h"
#include "icmp.h"
#include "igmp.h"
#include "addhdr.h"
#include "tcp.h"
#include "udp.h"

#include "socket.h"
#include "error.h"
#include "xgetopt.h"
#include "data.h"
#include "hexa.h"
#include "memory.h"
#include "netconfig.h"
#include "packet.h"
#include "printpkt.h"
#include "recv.h"
#include "random.h"
#include "str.h"
#include "xtime.h"
#include "usage.h"
#include "ignecho.h"

char *progname;
int ok;
struct stt_s stt;
struct opt_s opt;
struct ipopt_s ipopt;
struct ethopt_s ethopt;
struct arpopt_s arpopt;
struct tcpopt_s tcpopt;
struct icmpopt_s icmpopt;
struct sockopt_s sockopt;

void version (void);

#endif /* __MAKETH_H__ */
