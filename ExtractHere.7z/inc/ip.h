/*
 * \file ip.h
 * \brief header for ip protocol
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __IP_H__
#define __IP_H__

#include "maketh.h"

#define IPv4SIZE 17
#define U_IP 4
#define MAX_IP 0xff

#define IPHDR_SIZE sizeof (struct xiphdr)
#define MORE_FRAGMENT 0x2000
#define ADD_FRAGOFF(y) (u_int) (y - IPHDR_SIZE) / 8

#define IPID_RANDOM 0x01
#define IPTTL_RANDOM 0x02
#define IPSRC_RANDOM 0x04

#define MAX_IPOPTLEN 40
#define IPOPT_COPIED 0x80
#define IPOPT_LSRR 0x03
#define IPOPT_RR 0x07
#define IPOPT_SSRR 0x09

struct ipopt_s
  {
    u32 src;
    u32 dst;
    u8 ttl;
    u8 id;
    u8 ihl;
    u8 lenopt;
    u8 lenhdr;
    u_int fragoff;
    u_char opt[MAX_IPOPTLEN];
    u_char option;
  };

/* this orignial structure */
struct xiphdr {
#if defined(__PROC_IS_LITTLE_ENDIAN)
        u8    ihl:4,
                version:4;
#elif defined (__PROC_IS_BIG_ENDIAN)
        u8    version:4,
                ihl:4;
#else
#error  "Please fix <asm/byteorder.h>"
#endif
        u8    tos;
        u16  tot_len;
        u16  id;
        u16  frag_off;
        u8    ttl;
        u8    protocol;
        __sum16 check;
        u32  saddr;
        u32  daddr;
        /*The options start here. */
};

u32 get_ip (const char *target);
void ip_make_hdr (char *packet, int sizefrag);
u32 ip_create_random (void);
u32 ip_create_to_network_mask (u32 mask);
void set_route (const char *route);
char ** get_route (const char *pkt, int off);
void print_route (char **rroute);
void free_route (char **route);

#endif /* __IP_H__ */
