/*
 * \file config.h
 * \brief all macro
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __CONFIG_H__
#define __CONFIG_H__

/* max size */
#define NETDEVICE_LEN 10
#define PORT_MAX 0xffff
#define MAX_DEFAULT 0xffff
#define DEFAULT 0xfff

/* option */
#define PSRC_RANDOM 0x10
#define PDST_RANDOM 0x20

#endif /* __CONFIG_H__ */
