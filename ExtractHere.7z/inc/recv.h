/*
 * \file recv.h
 * \brief header for recv.c
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __RECV_H__
#define __RECV_H__

#define VERBOSE_RECV 0x01
#define HEXA_RECV 0x02
#define NO_RECV 0x04

void * func_packet_recv (void *a);
void recv_check_packet (const char *pkt, int sizepkt, int *n_current);

#endif /* __RECV_H__ */
