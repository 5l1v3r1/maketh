/*
 * \file ignecho.c
 * \brief ignore or unignore echo request
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

int
ignore_echo (int mode)
{
#ifdef __OS_IS_LINUX
  char c;
  int fd;

  fd = open (LINUX_FILE_IGN_ECHO, O_RDWR);
  if (fd == -1)
    {
      error (0, "[open()] ", strerror (errno), "\n", NULL);
      return 2;
    };

  if (!mode)
    {
      if (read (fd, &c, sizeof (char)) == -1)
	{
	  error (0, "[read()] ", strerror (errno), "\n", NULL);
	  close (fd);
	  return 2;
	}

      if (c == '1')
	{
	  close (fd);
	  return 2;
	}
      else
	{
	  lseek(fd, SEEK_SET, 0);
	  if (write (fd, "1", sizeof (char)) == -1)
	    error (0, "ignore echo fails.\n", NULL);
	  close (fd);
	  return 1;
	}
    }
  else if (mode == 1)
    {
      if (write (fd, "0", sizeof (char)) == -1)
	error (0, "ignore echo fails.\n", NULL);
    }

  close (fd);
#else /* __OS_IS_BSD */
  printf("option not implented,, because it's taff for a firewall.\n");
#endif /* end check OS */

  return 0;
}
