/*
 * \file udp.c
 * \brief operation on udp header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
udp_make_hdr (char *packet)
{
  char buff[PKTSIZE_MAX] = {0};
  struct xudphdr *udp = (struct xudphdr *)packet;
  struct addhdr_s addhdr;

  udp->source = (opt.option & PSRC_RANDOM) ?
    htons (get_random_number (PORT_MAX)) :
    htons (opt.psrc);
  udp->dest = (opt.option & PDST_RANDOM) ?
    htons (get_random_number (PORT_MAX)) :
    htons (opt.pdst);
  udp->len = htons (opt.lendata);
  udp->check = 0;

  memcpy (&addhdr.saddr, &ipopt.src, sizeof (u32));
  memcpy (&addhdr.daddr, &ipopt.dst, sizeof (u32));
  addhdr.useless = htons(0);
  addhdr.protocol = IPPROTO_UDP;
  addhdr.length = htons (opt.lendata);

  memcpy (buff, udp, UDPHDR_SIZE);
  memcpy (buff + UDPHDR_SIZE, &addhdr, ADDHDR_SIZE);
  memcpy (buff + UDPHDR_SIZE + ADDHDR_SIZE, packet + UDPHDR_SIZE,
          opt.lendata - UDPHDR_SIZE);

  udp->check = packet_in_cksum ((unsigned short *)buff,
                                opt.lendata + ADDHDR_SIZE);
}
