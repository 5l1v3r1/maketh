/*
 * \file packet.c
 * \brief send packet
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

int
packet_type (void)
{
  pthread_t thread_recv;
  int ret, mode;

  if (opt.option & IGN_ECHO)
    mode = ignore_echo (mode);

  if (!(opt.option & NO_RECV))
    {
      ok = 1;
      if (pthread_create (&thread_recv, NULL, func_packet_recv, NULL) == -1)
	error (0, "[pthread_create()] error to create new thread\n", NULL);
    }

  printf ("send packet to: %s with protocol: ", opt.target_orig);
  switch (opt.protocol)
    {
    case ARP:
      printf ("ARP\n\n");
      break;
    case IP:
      printf ("IP\n\n");
      break;
    case TCP:
      printf ("TCP\n\n");
      break;
    case UDP:
      printf ("UDP\n\n");
      break;
    case ICMP:
      printf ("ICMP\n\n");
      break;
    }

  opt.target_orig = NULL;
  if (opt.protocol == ARP)
    ret = packet_send_lan ();
  else
    ret = packet_send_wan ();

  if (!(opt.option & NO_RECV))
    {
      sleep (1);
      ok--;
      pthread_join (thread_recv, NULL);
    }

  if (opt.option & IGN_ECHO && mode != 2)
    mode = ignore_echo (mode);

  printf ("Send packet finish, static is : Send: %ld  Recv: %ld\n",
	  stt.send, stt.recv);

  return ret;
}

#define SEND_PACKET_TIMEOUT              \
  do                                     \
    {                                    \
switch (GET_NBIT (opt.option, 7))        \
  {				         \
  case 0:		                 \
    sleep (opt.timeout);                 \
    break;		                 \
  default:		                 \
    usleep (opt.timeout);                \
    break;		                 \
  } /* switch */			 \
    } /* do while */			 \
  while (0)

int
packet_send_lan (void)
{
  int i;
  char packet[ARPPKT_SIZE];
  struct arphdr_s *arp = NULL;
  struct socket_s socket;

  sockopt.init_socket (&socket, opt.protocol);
  arp = (struct arphdr_s *) (packet + ETHHDR_SIZE);
  ethernet_make_hdr (packet);

  arp->a.ar_hrd = htons (ARPHRD_ETHER);
  arp->a.ar_pro = htons (ETH_P_IP);
  arp->a.ar_hln = 6;
  arp->a.ar_pln = 4;
  arp->a.ar_op = htons (arpopt.opcode);
  memcpy (arp->ar_sha, arpopt.sha, 6);
  memcpy (arp->ar_tha, arpopt.tha, 6);
  memcpy (arp->ar_sip, arpopt.sip, 4);
  memcpy (arp->ar_tip, arpopt.tip, 4);

  i = opt.count;
  while (i--)
    {
      if (sockopt.send_packet (&socket, packet, ARPPKT_SIZE) == -1)
	{
	  return -1;
	  close (socket.fd);
	}

      SEND_PACKET_TIMEOUT;
      stt.send++;
      i++;
    }

  close (socket.fd);
  return 0;
}

#define IP_CHANGE_RANDOM                      \
  do                                          \
    {                                         \
  if (ipopt.option & IPID_RANDOM)             \
    ipopt.id++;				      \
  if (ipopt.option & IPTTL_RANDOM)	      \
    ipopt.ttl = get_random_number (0xff);     \
  if (ipopt.option & IPSRC_RANDOM)     	      \
    ipopt.src = ip_create_random ();	      \
    }                                         \
  while (0)

int
packet_send_wan (void)
{
  int totlen, nfrag, i;
  int size, off, curfrag;
  char *packet = NULL;
  char *buffer = NULL;
  struct socket_s socket;

  sockopt.init_socket (&socket, opt.protocol);
  totlen = ipopt.lenhdr + opt.lendata + opt.hdrsize;
  nfrag = (totlen / opt.mtu) + 1;

  packet = xmalloc (opt.off_ip + ipopt.lenhdr  +
		    opt.lendata + opt.hdrsize);
  if (sockopt.sock_mode & SOCK_LL)
    ethernet_make_hdr (packet);

  if (opt.protocol != IP)
    {
      buffer = xmalloc (opt.lendata + opt.hdrsize);
      if (opt.lendata)
	{
	  memcpy (buffer + opt.hdrsize, opt.data, opt.lendata);
	  xfree (opt.data);
	  opt.data = NULL;
	}
    }

  i = opt.count;
  opt.lendata += opt.hdrsize;
  while (i--)
    {

#if 0
  because protocol IGMP not implented
      if (opt.protocol == IGMP) igmp_make_hdr (buffer);
#endif
      if (opt.protocol == ICMP) icmp_make_hdr (buffer);
      else if (opt.protocol == UDP) udp_make_hdr (buffer);
      else if (opt.protocol == TCP) tcp_make_hdr (buffer);

      off = 0;
      size = opt.mtu;
      ipopt.fragoff = MORE_FRAGMENT;

      curfrag = nfrag;
      while (curfrag--)
   {
     if (!curfrag)
       {
         size = totlen % (opt.mtu - ipopt.lenhdr);
         ipopt.fragoff -= MORE_FRAGMENT;
       }

     ip_make_hdr (packet, size);
     if (opt.protocol != IP || buffer)
       memcpy (packet + ipopt.lenhdr + opt.off_ip,
	       buffer+off, size - ipopt.lenhdr);

     if (sockopt.send_packet (&socket, packet, size + opt.off_ip) == -1)
       {
	 close (socket.fd);
	 return -1;
       }
     off += size - ipopt.lenhdr;
     ipopt.fragoff += ADD_FRAGOFF (opt.mtu);
   }

      stt.send++;
      IP_CHANGE_RANDOM;
      SEND_PACKET_TIMEOUT;
    }

  close (socket.fd);
  xfree (buffer);
  xfree (packet);
  return 0;
}

unsigned short
packet_in_cksum(unsigned short * addr,int len)
{
/* This function is not coded by me */
  register int sum = 0;
  u_short answer = 0;

  register u_short * w = addr;
  register int nleft = len;

  while(nleft > 1) {
    sum += *w++;
    nleft -= 2;
  }

  if(nleft == 1) {
    *(u_char *)(&answer) = *(u_char *) w;
    sum += answer;
  }

  sum = (sum >> 16) + (sum & 0xffff);

  sum += (sum >> 16);
  answer = ~sum;

  return answer;
}
