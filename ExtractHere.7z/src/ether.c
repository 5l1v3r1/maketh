/*
 * \file ether.c
 * \brief operation on ethenet header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
ethernet_make_hdr (char *packet)
{
  struct xethhdr *eth = NULL;

  eth = (struct xethhdr *)packet;
  memcpy (eth->h_source, ethopt.src, ETH_ALEN);
  memcpy (eth->h_dest, ethopt.dst, ETH_ALEN);
  eth->h_proto = (opt.protocol == ARP) ?
    htons (ETH_P_ARP) :
    htons (ETH_P_IP);
}

void
set_mac_to_str (char *smac, u_char *umac)
{
  int i;
  char buff[3];
  u_char *pumac = umac;

  if (strlen (smac) > 17)
    error (1, "fatal error, addr mac invalid, is to big\n", NULL);

  buff[2] = '\0';
  for (i = 0; i < strlen (smac); i += 3)
    {
      buff[0] = smac[i];
      buff[1] = smac[i + 1];
      *pumac++ = strtol (buff, NULL, 16);
    }
}
