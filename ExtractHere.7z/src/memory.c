/*
 * \file memory.c
 * \brief function for operation on memory
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
clean (void *var, int size)
{
  char *p_var = var;

  while (size--)
    *p_var++ = 0;
}

void *
xmalloc (size_t size)
{
  void *ptr = NULL;

  if (size < 1)
    error (1, "[xmalloc()] invalid size.\n", NULL);

  ptr = malloc (size);
  if (!ptr)
    error (1, "[malloc()] memory exausted.\n", NULL);

  return ptr;
}

void *
xcalloc (size_t size)
{
  void *ptr = NULL;

  ptr = xmalloc (size);
  clean (ptr, size);

  return ptr;
}

char *
xstrdup (const char *orig)
{
  int size;
  char *copy = NULL;

  size = strlen (orig);
  copy = xmalloc (size + 1);
  *(copy + size) = 0;
  strncpy (copy, orig, size);

  return copy;
}

void
xfree (void *ptr)
{
  if (ptr)
    free (ptr);
}
