/*
 * \file icmp.c
 * \brief operation on icmp header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
icmp_make_hdr (char *header)
{
  struct xicmphdr *icmp = (struct xicmphdr *)(header);

  icmp->type = icmpopt.type;
  icmp->code = icmpopt.code; 
  icmp->un.echo.id = (icmpopt.random & ICMPID_RANDOM) ?
    htons (icmpopt.id++) :
    htons (icmpopt.id);
  icmp->un.echo.sequence = (icmpopt.random & ICMPSEQ_RANDOM) ?
    htons (icmpopt.seq++) :
    htons (icmpopt.seq);
  if (icmpopt.type == DEST_UNREACHABLE ||
      icmpopt.type == SRC_QUENCH ||
      icmpopt.type == REDIRECT ||
      icmpopt.type == TIME_EXCEEDED ||
      icmpopt.type == PARAM_UNINTELLIGIBLE)
    {
      icmp_add_hdr_ip (header + ICMPHDR_SIZE);
      if (icmpopt.tcp)
        icmp_add_hdr_tcp (header + (ICMPHDR_SIZE + IPHDR_SIZE));
      else
        icmp_add_hdr_udp (header + (ICMPHDR_SIZE + IPHDR_SIZE));
      if (icmpopt.type == REDIRECT)
        memcpy (&icmp->un.gateway, &icmpopt.router, sizeof (u32));
    }
  else if (icmpopt.type == TIMESTAMP_REQUEST ||
	   icmpopt.type == TIMESTAMP_REPLY)
    icmp_set_timestamp (header + ICMPHDR_SIZE);
  icmp->checksum = 0;
  icmp->checksum = packet_in_cksum((unsigned short *)
                    header, opt.lendata);
}

void
icmp_add_hdr_ip (char *add_ip)
{
  struct xiphdr *ip = (struct xiphdr *)add_ip;

  ip->ihl = 5;
  ip->version = 4;
  ip->tos = 0;
  ip->id = htons (icmpopt.ip.id);
  ip->frag_off = htons (icmpopt.ip.fragoff);
  ip->ttl = icmpopt.ip.ttl;
  ip->tot_len = htons(icmpopt.totlen);
  ip->protocol = icmpopt.proto;
  memcpy (&ip->daddr, &icmpopt.ip.dst, sizeof (u32));
  memcpy (&ip->saddr, &icmpopt.ip.src, sizeof (u32));
  ip->check = 0;
  ip->check = packet_in_cksum ((unsigned short *)ip, IPHDR_SIZE);
}

void
icmp_add_hdr_tcp (char *hdr)
{
  struct addtcp_s *addtcp = (struct addtcp_s *)hdr;

  addtcp->psrc = htons (icmpopt.t.tcp.psrc);
  addtcp->pdst = htons (icmpopt.t.tcp.pdst);
  addtcp->seq = htonl (icmpopt.t.tcp.seq);
}


void
icmp_add_hdr_udp (char *hdr)
{
  struct addudp_s *addudp = (struct addudp_s *)hdr;

  addudp->psrc = htons (icmpopt.t.udp.psrc);
  addudp->pdst = htons (icmpopt.t.udp.pdst);
  addudp->len = htons (icmpopt.t.udp.len);
  addudp->check = htons (icmpopt.t.udp.check);
}

void
icmp_set_timestamp (char *hdr)
{
  struct time_s *timestamp = (struct time_s *)hdr;

  timestamp->orig = (icmpopt.random & ICMPTIME_ORIG_RANDOM) ?
    htonl (get_icmp_timestamp (time (NULL))) :
    htonl (icmpopt.t.time.orig);
  if (icmpopt.type == TIMESTAMP_REQUEST)
    {
      timestamp->recv = 0;
      timestamp->send = 0;
    }
  else
    {
      timestamp->send = (icmpopt.random & ICMPTIME_SEND_RANDOM) ?
	htonl (get_icmp_timestamp (time (NULL))) :
	htonl (icmpopt.t.time.send);
      timestamp->recv = (icmpopt.random & ICMPTIME_RECV_RANDOM) ?
	htonl (get_icmp_timestamp (time (NULL))) :
	htonl (icmpopt.t.time.recv);
    }
}

char *
icmp_get_name_type (int type)
{
  switch (type)
    {
      case ECHO_REPLY:
        return "Echo type";
        break;
      case DEST_UNREACHABLE:
        return "Destination unreachable";
        break;
      case SRC_QUENCH:
        return "Source quench";
        break;
      case REDIRECT:
        return "Redirect";
        break;
      case ECHO_REQUEST:
        return "Echo request";
        break;
      case TIME_EXCEEDED:
        return "Time exceeded";
        break;
      case PARAM_UNINTELLIGIBLE:
        return "Parameter (IP) unintelligible";
        break;
      case TIMESTAMP_REQUEST:
        return "Timestamp request";
        break;
      case TIMESTAMP_REPLY:
        return "Timestamp reply";
        break;
      case INFO_REQUEST:
        return "Information request";
        break;
      case INFO_REPLY:
        return "Information reply";
        break;
      case ADDR_MASK_REQUEST:
        return "Address mask request";
        break;
      case ADDR_MASK_REPLY:
        return "Address mask reply";
        break;
    }

  return "Unknow type";
}
