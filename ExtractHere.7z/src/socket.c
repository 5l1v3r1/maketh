/*
 * \file socket.c
 * \brief operation on socket
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

#ifdef __OS_IS_LINUX
/**
 * Ethernet socket for linux
 */

void
linux_eth_socket_open (struct socket_s *sock, int protocol)
{
  sock->fd = create_new_socket (AF_PACKET, SOCK_RAW, protocol);
  memset (&sock->s.ll, 0, sizeof (struct sockaddr_ll));
  sock->s.ll.sll_family = AF_PACKET;
  sock->s.ll.sll_protocol = htons (ETH_P_ALL);
  sock->s.ll.sll_ifindex = opt.i_device;
  if (!(opt.option & NO_RECV))
    linux_eth_bind (sock);
}

void
linux_eth_bind (struct socket_s *socket)
{
  if (bind (socket->fd, (struct sockaddr *)&socket->s.ll,
	    sizeof (struct sockaddr_ll)) == -1)
    error (1, "[bind()] ", strerror (errno), "\n", NULL);
}

int
linux_eth_send (struct socket_s *s, char *packet, int size)
{
  int n_send;

  n_send = sendto (s->fd, packet, size, 0,
                    (struct sockaddr *)&s->s.ll, sizeof (struct sockaddr_ll));
  if (n_send == -1)
    error (0, "[sendto()] ", strerror (errno), "\n", NULL);

  return n_send;
}

#else /* __OS_IS_BSD */
/**
 * Ethernet socket for BSD
 */

void
BSD_open_eth_device (struct socket_s *sock, int protocol)
{
  int n_device, yes;
  struct ifreq device;
  char buff[15] = {0};

  for (n_device = 0; n_device < 10; n_device++)
    {
      snprintf (buff, sizeof (buff) - 1, "/dev/bpf%d", n_device); 
      sock->fd = open (buff, O_RDWR);
      if (sock->fd != -1)
	break;
    }

  if (sock->fd == -1)
    error (1, "BPF not found ...\n", NULL);

  if (xioctl (sock->fd, BIOCGBLEN, (void *)&sock->sizepkt, IOCTL_TYPE_INT) == -1)
    {
      close (sock->fd);
      error (1, "get pkt size unknow\n", NULL);
    }

  if (sock->sizepkt < opt.mtu)
    {
      close (sock->fd);
      error (1, "get size packet with BIOCGBLEN > MTU!\n", NULL);
    }

  strncpy (device.ifr_name, opt.devname, NETDEVICE_LEN -1);
  if (xioctl (sock->fd, BIOCSETIF, (void *)&device, IOCTL_TYPE_IFREQ) == -1)
    {
      close (sock->fd);
      error (1, "attached bpf on network device <", opt.devname, ">fails", NULL);
    }

  yes = 1;
  if (xioctl (sock->fd, BIOCIMMEDIATE, (void *)&yes, IOCTL_TYPE_INT) == -1)
    error (0, "warning, maybe this packet stcked in buffer\n", NULL); 
}

int
BSD_eth_send (struct socket_s *s, char *packet, int size)
{
  int n_write;

  n_write = write (s->fd, packet, size);
  if (n_write == -1)
    error (0, "[write()] ", strerror (errno), "\n", NULL);

  return n_write;
}
#endif /* end test OS */

int
create_new_socket (int domain, int type, int protocol)
{
  int fd_sock;

  fd_sock = socket (domain, type, protocol);
  if (fd_sock == -1)
    error (1, "[socket()] ", strerror (errno), "\n", NULL);

  return fd_sock;
}

void
init_socket_in (struct socket_s *sock, int protocol)
{
  sock->fd = create_new_socket (AF_INET, SOCK_RAW, protocol);
  sock->s.in.sin_family = AF_INET;
  sock->s.in.sin_port = 0x00;
  memcpy (&sock->s.in.sin_addr, &ipopt.dst, sizeof (u32));
  xsetsockopt (sock->fd);
}

void
xsetsockopt (int socket)
{
  int res;
  int ret;

  res = sizeof(int);
  ret = setsockopt (socket, IPPROTO_IP, IP_HDRINCL, (char *)&res, res);
  if (ret == -1)
    error (1, "[setsockopt()] ", strerror (errno), "\n");
}

int
send_in (struct socket_s *s, char *packet, int size)
{
  int n_send;

  n_send = sendto (s->fd, packet, size, 0,
		   (struct sockaddr *)&s->s.in, sizeof (struct sockaddr_in));
  if (n_send == -1)
    error (0, "[sendto()] ", strerror (errno), "\n", NULL);

  return n_send;
}
