/*
 * \file main.c
 * \brief main function
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

int
main (int argc, char **argv)
{
  int ret;

  srand (time (NULL));
  progname = argv[0];

  if (getuid())
    error (1, "Only the user 'root' can use this program, it use "
	   "raw socket.\n", NULL);

  if (geteuid())
    {
      if (setuid (getuid ()) == -1)
        error (1, "euid != 0, cannot change euid to uid.\n");
    }

  ret = decode_opts (argc, argv);
  if (ret == -1)
    error (0, "try ", progname, " --help\nif you found any bug please send mail at : ",
	   PACKAGE_BUGREPORT, "\n",  NULL);
  else
    packet_type ();

  xfree (opt.data);
  return (!ret) ? EXIT_SUCCESS : EXIT_FAILURE;
}

void
version (void)
{
  printf ("Maketh version %s\n", VERSION);
  exit (EXIT_SUCCESS);
}
