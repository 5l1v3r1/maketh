/*
 * \file printpkt.c
 * \brief print packet receved
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
print_ethernet (const char *pkt)
{
  struct xethhdr *eth = (struct xethhdr *) pkt;
  printf ("===== Ethernet =====\n");
  printf ("Mac src/dst: %x:%x:%x:%x:%x:%x/%x:%x:%x:%x:%x:%x\n",
	  eth->h_source[0], eth->h_source[1], eth->h_source[2], eth->h_source[3],
	  eth->h_source[4], eth->h_source[5], eth->h_dest[0], eth->h_dest[1],
	  eth->h_dest[2], eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
}

int
print_ethernet_hexa (const char *pkt)
{
  int newline, i;
  struct xethhdr *eth = (struct xethhdr *) pkt;

  newline = 0;
  for (i = 0; i < 6; i++)
    print_hexa (sizeof (eth->h_dest[i]), (u_int) eth->h_dest[i], &newline);

  for (i = 0; i < 6; i++)
    print_hexa (sizeof (eth->h_source[i]), (u_int) eth->h_source[i], &newline);

  print_hexa (sizeof (eth->h_proto), (u_int) htons (eth->h_proto), &newline);

  return newline;
}

void
print_arp (struct arphdr_s *arp)
{
  printf ("===== ARP =====\n");
  printf ("Mac src/dst: %x:%x:%x:%x:%x:%x/%x:%x:%x:%x:%x:%x\n",
	  arp->ar_sha[0], arp->ar_sha[1], arp->ar_sha[2], arp->ar_sha[3],
	  arp->ar_sha[4], arp->ar_sha[5], arp->ar_tha[0], arp->ar_tha[1],
	  arp->ar_tha[2], arp->ar_tha[3], arp->ar_tha[4], arp->ar_tha[5]);
  printf ("IP src/dst: %d.%d.%d.%d/%d.%d.%d.%d\n",
	  arp->ar_sip[0], arp->ar_sip[1], arp->ar_sip[2], arp->ar_sip[3],
	  arp->ar_tip[0], arp->ar_tip[1], arp->ar_tip[2], arp->ar_tip[3]);
  printf ("OPcode: %d", htons (arp->a.ar_op));
}

void
print_arp_hexa (struct arphdr_s *arp, int *newline)
{
  int i;

  print_hexa (sizeof (arp->a.ar_hrd), (u_int) htons (arp->a.ar_hrd), newline);
  print_hexa (sizeof (arp->a.ar_pro), (u_int) htons (arp->a.ar_pro), newline);
  print_hexa (sizeof (u_char), (u_int) arp->a.ar_hln, newline);
  print_hexa (sizeof (u_char), (u_int) arp->a.ar_pln, newline);
  print_hexa (sizeof (arp->a.ar_op), (u_int) htons (arp->a.ar_op), newline);

  for (i = 0; i < 6; i++)
    print_hexa (sizeof (u_char), (u_int) arp->ar_sha[i], newline);

  for (i = 0; i < 4; i++)
    print_hexa (sizeof (u_char), (u_int) arp->ar_sip[i], newline);

  for (i = 0; i < 6; i++)
    print_hexa (sizeof (u_char), (u_int) arp->ar_tha[i], newline);

  for (i = 0; i < 4; i++)
    print_hexa (sizeof (u_char), (u_int) arp->ar_tip[i], newline);
}

void
print_ip_verbose (const char *pkt, int offset, int size)
{
  struct xiphdr *ip = (struct xiphdr *) pkt;
  struct in_addr addr;

  memcpy (&addr, &ip->saddr, sizeof (struct in_addr));
  printf ("============ IP Header ============\n"
	  "IP Src/Dst: %s / ", inet_ntoa (addr));
  memcpy (&addr, &ip->daddr, sizeof (struct in_addr));
  printf ("%s\n", inet_ntoa (addr));
  printf ("Version: %d\nIHL: %d\nTot len: %d\nID/TTL: %d / %d\nFrag (Y/N): ",
	  ip->version, ip->ihl, htons (ip->tot_len), htons (ip->id), ip->ttl);
  if (ip->frag_off != 0 && htons (ip->frag_off) != 0x4000)
    printf ("Y\n");
  else
    printf ("N\n");
  printf ("Checksum: 0x%x\nOption (Y/N): ", htons (ip->check));
  offset += IPHDR_SIZE;
  if (ip->ihl > 5 && offset < size)
    {
      printf ("Y\n");
      char **l = get_route (pkt + offset, (offset - IPHDR_SIZE) - 4);
      free_route (l);
    }
  else
    printf ("N\n");
}

void
print_ip (const char *pkt, int offset, int size)
{
  struct xiphdr *ip = (struct xiphdr *) pkt;
  struct in_addr addr;
  char **rroute = NULL;

  memcpy (&addr, &ip->saddr, sizeof (struct in_addr));
  printf ("IP: %s  ID: %d  TTL: %d",
	  inet_ntoa (addr), ntohs (ip->id), ip->ttl);

  if (ip->ihl > 5 && offset < size)
    {
      printf ("  Opt: Y\n");
      rroute = get_route (pkt + (offset + IPHDR_SIZE), (offset - IPHDR_SIZE) - 4);
      if (!rroute)
	return;
      print_route (rroute);
      free_route (rroute);
    }
  else
    printf ("\n");
}

void
print_ip_hexa (const char *pkt, int offset, int *newline)
{
  struct xiphdr *ip = (struct xiphdr *) pkt;
  struct in_addr addr;
  char **rroute = NULL;
  u_char buff;
  int i;

  buff = 0;
  buff = ip->version;
  buff |= (buff << 4) | ip->ihl;
  print_hexa (sizeof (u_char), (u_int) buff, newline);
  print_hexa (sizeof (ip->tos), (u_int) ip->tos, newline);
  print_hexa (sizeof (ip->tot_len), (u_int) htons (ip->tot_len), newline);
  print_hexa (sizeof (ip->id), (u_int) htons (ip->id), newline);
  print_hexa (sizeof (ip->frag_off), (u_int) htons (ip->frag_off), newline);
  print_hexa (sizeof (ip->ttl), (u_int) ip->ttl, newline);
  print_hexa (sizeof (ip->protocol), (u_int) ip->protocol, newline);
  print_hexa (sizeof (ip->check), (u_int) htons (ip->check), newline);
  print_hexa (sizeof (ip->saddr), (u_int) htonl (ip->saddr), newline);
  print_hexa (sizeof (ip->daddr), (u_int) htonl (ip->daddr), newline);

  if (ip->ihl > 5 && *(pkt + IPHDR_SIZE) == IPOPT_RR)
    {
      rroute = get_route (pkt + IPHDR_SIZE, (offset - IPHDR_SIZE) - 4);
      if (!rroute)
	return;

      print_hexa (sizeof (u_char), (u_int) *(pkt + IPHDR_SIZE), newline);
      print_hexa (sizeof (u_char), (u_int) *(pkt + IPHDR_SIZE + 1), newline);
      print_hexa (sizeof (u_char), (u_int) *(pkt + IPHDR_SIZE + 2), newline);

      i = 0;
      while (rroute[i])
	{
	  addr.s_addr = inet_addr (rroute[i++]);
	  print_hexa (sizeof (addr.s_addr), (u_int) htonl (addr.s_addr), newline);
	}
      free_route (rroute);

      /* end option */
      print_hexa (sizeof (u_char), (u_int) 0x00, newline);
    }
}

void
print_icmp (const char *pkt)
{
  struct xicmphdr *icmp = (struct xicmphdr *)pkt;

  if (!(opt.option & VERBOSE_RECV))
    printf ("ICMP: Type: %d  Code: %d  ",
	    icmp->type, icmp->code);
  else
    printf ("============ ICMP Header ============\n"
	    "Type: %d\nCode: %d", icmp->type, icmp->code);

  if (icmp->type == REDIRECT)
    {
      print_icmp_gateway (icmp->un.gateway);
      print_icmp_add_header (pkt + ICMPHDR_SIZE);
    }
  else if (icmp->type == TIMESTAMP_REPLY)
    print_icmp_timestamp (pkt + ICMPHDR_SIZE);
  else if (icmp->type == DEST_UNREACHABLE ||
	   icmp->type == SRC_QUENCH)
    print_icmp_add_header (pkt + ICMPHDR_SIZE);
  else
    {
      if (!(opt.option & VERBOSE_RECV))
	printf ("ID: %d  Seq: %d", htons (icmp->un.echo.id),
		htons (icmp->un.echo.sequence));
      else
	printf ("\nID: %d\nSeq: %d", htons (icmp->un.echo.id),
		htons (icmp->un.echo.sequence));
    }
}

void
print_icmp_gateway (u32 ip_gateway)
{
  struct in_addr addr;

  memcpy (&addr, &ip_gateway, sizeof (struct in_addr));
  printf("Gateway: %s\n", inet_ntoa (addr));
}

void
print_icmp_timestamp (const char *pkt)
{
  struct time_s *timestamp = (struct time_s *) pkt;

  printf("\nICMP-Timestamp: Orig = %d  send = %d  recv = %d",
	 ntohl (timestamp->orig), ntohl (timestamp->send), ntohl (timestamp->recv));
}

void
print_icmp_add_header (const char *pkt)
{
  struct in_addr addr;
  struct xudphdr *udp = NULL;
  struct xiphdr *ip = (struct xiphdr *) pkt;

  memcpy (&addr, &ip->saddr, sizeof (struct in_addr));
  printf ("\nICMP-ADD IP: src: %s  dst: ", inet_ntoa (addr));
  memcpy (&addr, &ip->daddr, sizeof (struct in_addr));
  printf ("%s  TTL: %d  ID: %d\n", inet_ntoa (addr), ip->ttl, htons (ip->id));

  if (ip->protocol == UDP)
    printf ("ICMP-ADD UDP:  ");
  else if (ip->protocol == TCP)
    printf ("ICMP-ADD TCP:  ");

  udp = (struct xudphdr *) (pkt + IPHDR_SIZE);
  printf ("port src: %d  port dst: %d", htons (udp->source), htons (udp->dest));
}

void
print_icmp_hexa (const char *pkt, int size, int *newline)
{
  struct xicmphdr *icmp = (struct xicmphdr *) pkt;
  struct time_s *tstamp = NULL;
  struct xiphdr *ip = NULL;
  struct addudp_s *udp = NULL;
  struct addtcp_s *tcp = NULL;

  print_hexa (sizeof (icmp->type), (u_int) icmp->type, newline);
  print_hexa (sizeof (icmp->code), (u_int) icmp->code, newline);
  print_hexa (sizeof (icmp->checksum), (u_int) htons (icmp->checksum), newline);
  print_hexa (sizeof (icmp->un.echo.id),
	      (u_int) htons (icmp->un.echo.id), newline);
  print_hexa (sizeof (icmp->un.echo.sequence),
	      (u_int) htons (icmp->un.echo.sequence), newline);

  if (icmp->type == TIMESTAMP_REPLY)
    {
      tstamp = (struct time_s *) (pkt + ICMPHDR_SIZE);
      print_hexa (sizeof (tstamp->orig), (u_int) htonl (tstamp->orig), newline);
      print_hexa (sizeof (tstamp->orig), (u_int) htonl (tstamp->recv), newline);
      print_hexa (sizeof (tstamp->send), (u_int) htonl (tstamp->send), newline);
    }

  else if (icmp->type == SRC_QUENCH ||
	   icmp->type == DEST_UNREACHABLE)
    {
      print_ip_hexa (pkt + ICMPHDR_SIZE, 0, newline);
      ip = (struct xiphdr *) (pkt + ICMPHDR_SIZE);
      switch (ip->protocol)
	{
	case UDP:
	  udp = (struct addudp_s *) (pkt + ICMPHDR_SIZE + ((ip->ihl * 32) / 8));
	  print_hexa (sizeof (udp->psrc), (u_int) htons (udp->psrc), newline);
	  print_hexa (sizeof (udp->pdst), (u_int) htons (udp->pdst), newline);
	  print_hexa (sizeof (udp->len), (u_int) htons (udp->len), newline);
	  print_hexa (sizeof (udp->check), (u_int) htons (udp->check), newline);
	  break;
	case TCP:
	  tcp = (struct addtcp_s *) (pkt + ICMPHDR_SIZE + ((ip->ihl * 32) / 8));
	  print_hexa (sizeof (tcp->psrc), (u_int) htons (tcp->psrc), newline);
	  print_hexa (sizeof (tcp->pdst), (u_int) htons (tcp->pdst), newline);
	  print_hexa (sizeof (tcp->seq), (u_int) htonl (tcp->seq), newline);
	  break;
	}
    }

  /**
   router
  print_hexa (sizeof (icmp->gateway), (u_int) htonl (gateway), newline);
  **/
}

void
print_tcp (const char *pkt, int size)
{
  struct xtcphdr *tcp = (struct xtcphdr *)pkt;

  printf ("TCP: Port src/dst: %d/%d  Seq/AckSeq: %d/%d  Flags: ",
	  htons (tcp->source), htons (tcp->dest),  htonl (tcp->seq),
	  htonl (tcp->ack_seq));
  if (tcp->syn) printf ("S");
  if (tcp->ack) printf ("A");
  if (tcp->rst) printf ("R");
  if (tcp->fin) printf ("F");
  if (tcp->psh) printf ("P");
  if (tcp->urg) printf ("U");
}

void
print_tcp_verbose (const char *pkt)
{
  struct xtcphdr *tcp = (struct xtcphdr *)pkt;

  printf ("============ TCP Header =============\n");
  printf ("Port src/dst: %d/%d\nSeq: %d\nAck-Seq: %d\n",
	  htons (tcp->source), htons (tcp->dest), htonl (tcp->seq),
	  htonl (tcp->ack_seq));
  printf ("Flags: ");
  if (tcp->syn) printf ("Syn ");
  if (tcp->ack) printf ("Ack ");
  if (tcp->rst) printf ("Rst ");
  if (tcp->fin) printf ("Fin ");
  if (tcp->psh) printf ("Psh ");
  if (tcp->urg) printf ("Urg ");
  printf ("\n");
  printf ("Windows: %d\nChecksum: 0x%x\nUrgPTR: %d",
	  htons (tcp->window), htons (tcp->check), htons (tcp->urg_ptr)); 
}

void
print_tcp_hexa (const char *pkt, int *newline)
{
  struct xtcphdr *tcp = (struct xtcphdr *)pkt;

  print_hexa (sizeof (tcp->source), (u_int) htons (tcp->source), newline);
  print_hexa (sizeof (tcp->dest), (u_int) htons (tcp->dest), newline);
  print_hexa (sizeof (tcp->seq), (u_int) htonl (tcp->seq), newline);
  print_hexa (sizeof (tcp->ack_seq), (u_int) htonl (tcp->ack_seq), newline);
  print_hexa (sizeof (u_char), (u_int) (tcp->doff << 4), newline);
  print_hexa (sizeof (u_char), (u_int) *(pkt + OFFSET_FLAGS), newline);
  print_hexa (sizeof (tcp->window), (u_int) htons (tcp->window), newline);
  print_hexa (sizeof (tcp->check), (u_int) htons (tcp->check), newline);
}
