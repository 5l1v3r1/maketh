/*
 * \file igmp.c
 * \brief operation on igmp header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
igmp_make_hdr (char *packet)
{
  struct xigmphdr *igmp = (struct xigmphdr *) packet;

  igmp->type = 0;
  igmp->code = 0;
  igmp->group = 0;
  igmp->csum = 0;
}

/*
struct igmpopt_s
  {
    __u8 type;
    __u8 code;
    __be32 group;
  };
*/
