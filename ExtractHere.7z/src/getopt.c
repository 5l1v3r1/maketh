/*
 * \file getopt.c
 * \brief get options for the program
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

int
decode_opts (int argc, char **argv)
{
  char c;
  char *filename = NULL;
  u_char buff;
  int index;
  int this_option_optind = optind ? optind : 1;
  int digit_optind = 0;
  int err;

  struct option long_options[] =
    {
      {"help", 0, NULL, 'h'},
      {"version", 0, NULL, 'v'},
      {"count", 1, NULL, 'c'},
      {"data", 1, NULL, 'l'},
      {"file", 1, NULL, 'f'},
      {"proto", 1, NULL, 'p'},
      {"index", 1, NULL, 'I'},
      {"device", 1, NULL, 'i'},
      {"mtu", 1, NULL, 'm'},
      {"timeout", 1, NULL, 'E'},
      {"ign-echo", 0, NULL, 0},

      /* csonfig recv */
      {"no-recv", 0, NULL, 'W'},
      {"verbose-recv", 0, NULL, 'V'},
      {"hexa-recv", 0, NULL, 'H'},

      /* ethernet */
      {"eth-src", 1, NULL, 'y'},
      {"eth-dst", 1, NULL, 'Y'},

      /* arp */
      {"opcode", 1, NULL, 'o'},
      {"ar-mac-src", 1, NULL, 'n'},
      {"ar-mac-dst", 1, NULL, 'N'},
      {"ar-ip-src", 1, NULL, 'b'},
      {"ar-ip-dst", 1, NULL, 'B'},

      /* ip */
      {"source", 1, NULL, 's'},
      {"rand-src", 0, NULL, 'k'},
      {"rand-ttl", 0, NULL, 1},
      {"rand-ip-id", 0, NULL, 2},
      {"ip-id", 1, NULL, 'D'},
      {"ttl", 1, NULL, 't'},
      {"rr", 0, NULL, 13},
      {"lsr", 1, NULL, 14},
      {"ssr", 1, NULL, 15},

      /* common igmp icmp */
      {"type", 1, NULL, 'T'},
      {"code", 1, NULL, 'C'},

      /* igmp */
      {"group", 1, NULL, 'G'},

      /* icmp */
      {"icmp-seq", 1, NULL, 'j'},
      {"icmp-id", 1, NULL, 'd'},
      {"router", 1, NULL, 'r'},
      {"add-type", 1, NULL, '0'},
      {"add-ip-src", 1, NULL, '1'},
      {"add-ip-dst", 1, NULL, '2'},
      {"add-p-src", 1, NULL, '3'},
      {"add-p-dst", 1, NULL, '4'},
      {"add-ip-proto", 1, NULL, '5'},
      {"add-ip-ttl", 1, NULL, '6'},
      {"add-ip-id", 1, NULL, '7'},
      {"add-ip-fragof", 1, NULL, '8'},
      {"add-tcp-seq", 1, NULL, '9'},
      {"add-udp-len", 1, NULL, 'z'},
      {"add-udp-check", 1, NULL, 'J'},
      {"add-ip-totlen", 1, NULL, 'Q'},
      {"time-orig", 1, NULL, 18},
      {"time-send", 1, NULL, 19},
      {"time-recv", 1, NULL, 20},

      /* common udp & tcp */
      {"psrc", 1, NULL, 'x'},
      {"pdst", 1, NULL, 'X'},

      /* tcp */
      {"tcp-seq", 1, NULL, 'e'},
      {"tcp-ack", 1, NULL, 'a'},
      {"syn", 0, NULL, 'S'},
      {"ack", 0, NULL, 'A'},
      {"rst", 0, NULL, 'R'},
      {"fin", 0, NULL, 'F'},
      {"psh", 0, NULL, 'P'},
      {"urg", 0, NULL, 'U'},
      {"window", 1, NULL, 'w'},
      {"urgptr", 1, NULL, 'u'},
      {"mss", 1, NULL, 'M'},
      {"tcp-timestamp", 1, NULL, 16},

      {NULL, 0, NULL, 0}
    };

  clean (&opt, sizeof (struct opt_s));
  clean (&ipopt, sizeof (struct ipopt_s));
  clean (&icmpopt, sizeof (struct icmpopt_s));
  clean (&sockopt, sizeof (struct sockopt_s));
  clean (&ethopt, sizeof (struct ethopt_s));
  clean (&arpopt, sizeof (struct arpopt_s));
  clean (&tcpopt, sizeof (struct tcpopt_s));
  
  ok = 1;
  err = 0;
  opt.count = 3;
  opt.option = 0;
  opt.data = NULL;
  opt.target_orig = NULL;
  opt.timeout = 3;
  opt.option |= SEC;
  opt.protocol = UNKNOW;
    
  ipopt.ihl = 5;
  ipopt.ttl = 169;
  ipopt.id = 1;
  ipopt.option |= IPID_RANDOM;
  clean (ipopt.opt, 40);

  opt.option |= PSRC_RANDOM;
  opt.option |= PDST_RANDOM;

  icmpopt.type = 8;
  icmpopt.code = 0;
  icmpopt.id = 1;
  icmpopt.seq = 1;
  icmpopt.totlen = get_random_number (MAX_DEFAULT);
  icmpopt.t.tcp.psrc = get_random_number (PORT_MAX);
  icmpopt.t.tcp.pdst = get_random_number (PORT_MAX);
  icmpopt.ip.ttl = get_random_number (0xff);
  icmpopt.ip.id = get_random_number (MAX_DEFAULT);
  icmpopt.ip.fragoff = 0;
  icmpopt.ip.src = ip_create_random ();
  icmpopt.ip.dst = ip_create_random ();
  icmpopt.t.time.orig = 0;
  icmpopt.t.time.send = 0;
  icmpopt.t.time.recv = 0;
  icmpopt.random |= ICMPSEQ_RANDOM;
  icmpopt.random |= ICMPID_RANDOM;
  icmpopt.random |= ICMPTIME_ORIG_RANDOM;
  icmpopt.random |= ICMPTIME_SEND_RANDOM;
  icmpopt.random |= ICMPTIME_RECV_RANDOM;

  tcpopt.doff = 5;
  tcpopt.seq = 1;
  tcpopt.ackseq = 0;
  tcpopt.random |= TCPSEQ_RANDOM;
  tcpopt.windows = MAX_DEFAULT;
  tcpopt.ptr = 0;

  arpopt.opcode = ARPOP_REQUEST;
  memcpy (arpopt.tha, MAC_NOT_INIT, 6);
  memcpy (ethopt.dst, MAC_BROADCAST, 6);

  do
    {
      c = getopt_long (argc, argv, OPT_LIST, long_options, &index);
      digit_optind = this_option_optind;
      switch (c)
        {
  /* program info */
  case 'h':
    err++;
    break;
  case 'v':
    version ();
    break;

  /* config program */
  case 'c':
    opt.count = strtoint (optarg);
    break;
  case 'p':
    if (!strcmp (optarg, "arp"))
      opt.protocol = ARP;
    else if (!strcmp (optarg, "ip"))
      opt.protocol = IP;
    else if (!strcmp (optarg, "icmp"))
      opt.protocol = ICMP;
    else if (!strcmp (optarg, "igmp"))
      opt.protocol = IGMP;
    else if (!strcmp (optarg, "udp"))
      opt.protocol = UDP;
    else if (!strcmp (optarg, "tcp"))
      opt.protocol = TCP;
    break;
  case 'l':
    opt.lendata = strtoint (optarg);
    break;
  case 'f':
    filename = xstrdup (optarg);
    break;
  case 'I':
    opt.i_device = strtoint (optarg) & 0xff;
    break;
  case 'i':
    strncpy (opt.devname, optarg, NETDEVICE_LEN);
    break;
  case 'm':
    opt.mtu = strtoint (optarg);
    break;
  case 'E':
    opt.timeout = get_timeout (optarg);
    break;
  case 0:
    opt.option |= IGN_ECHO;
    break;

  /* ethernet */
  case 'y':
    set_mac_to_str (optarg, ethopt.src);
    sockopt.sock_mode = SOCK_LL;
    break;
  case 'Y':
    set_mac_to_str (optarg, ethopt.dst);
    sockopt.sock_mode = SOCK_LL;
    break;

  /* arp && rarp */
  case 'o':
    arpopt.opcode = strtoint (optarg) & 0xff;
    break;
  case 'n':
    set_mac_to_str (optarg, arpopt.sha);
    break;
  case 'N':
    set_mac_to_str (optarg, arpopt.tha);
    break;
  case 'b':
    inet_aton (optarg, (struct in_addr *)arpopt.sip);
    break;
  case 'B':
    inet_aton (optarg, (struct in_addr *)arpopt.tip);
    break;

  /* ip */
  case 's':
    ipopt.src = get_ip (optarg);
    if (ipopt.src == -1)
      {
        xfree (filename);
        return -1;
      }
    break;
  case 'D':
    ipopt.id = strtoint (optarg);
    ipopt.option &= 0xfe;
    break;
  case 't':
    ipopt.ttl = strtoint (optarg) & 0xff;
    break;
  case 13:
    *(ipopt.opt) |= IPOPT_RR;
    break;
  case 14:
    set_route(optarg);
    *(ipopt.opt) |= IPOPT_LSRR;
    break;
  case 15:
    set_route(optarg);
    *(ipopt.opt) |= IPOPT_SSRR;
    break;
  case 'k':
    ipopt.option |= IPSRC_RANDOM;
    break;
 case 1:
    ipopt.option |= IPTTL_RANDOM;
    break;
  case 2:
    ipopt.option |= IPID_RANDOM;
    break;

  /* common igmp && icmp */
  case 'T':
    icmpopt.type = strtoint (optarg) & 0xff;
    break;
  case 'C':
    icmpopt.code = strtoint (optarg) & 0xff;
    break;

    /* igmp */
  case 'G':
    /*igmp group*/
    break;

    /* icmp */
  case 'd':
    icmpopt.id = strtoint (optarg);
    icmpopt.random &= 0xfd;
    break;
  case 'j':
    icmpopt.seq = strtoint (optarg);
    icmpopt.random &= 0xfe;
    break;
  case '0':
    if (!strcmp (optarg, "tcp"))
      icmpopt.tcp = 1;
    else if (!strcmp (optarg, "udp"))
      icmpopt.udp = 1;
    break;
  case '1':
    icmpopt.ip.src = get_ip (optarg);
    break;
  case '2':
    icmpopt.ip.dst = get_ip (optarg);
    break;
  case '3':
    icmpopt.t.tcp.psrc = strtoint (optarg) & 0xffff;
    break;
  case '4':
    icmpopt.t.tcp.pdst = strtoint (optarg) & 0xffff;
    break;
  case '5':
    icmpopt.proto = strtoint (optarg) & 0xff;
    break;
  case '6':
    icmpopt.ip.ttl = strtoint (optarg) & 0xff;
    break;
  case '7':
    icmpopt.ip.id = strtoint (optarg);
    break;
  case '8':
    icmpopt.ip.fragoff = strtoint (optarg);
    break;
  case '9':
    icmpopt.t.tcp.seq = strtoint (optarg);
    break;
  case 'z':
    icmpopt.t.udp.len = strtoint (optarg);
    break;
  case 'J':
    icmpopt.t.udp.check = strtoint (optarg);
    break;
  case 'Q':
    icmpopt.totlen = strtoint (optarg) & 0xffff;
    break;
  case 'r':
    icmpopt.router = get_ip (optarg);
    if (icmpopt.router == -1)
      {
        xfree (filename);
        return -1;
      }
    break;
  case 18:
    icmpopt.t.time.orig = htonl (strtoint (optarg));
    icmpopt.random &= 0xfb;
    break;
  case 19:
    icmpopt.t.time.send = htonl (strtoint (optarg));
    icmpopt.random &= 0xf7;
    break;
  case 20:
    icmpopt.t.time.recv = htonl (strtoint (optarg));
    icmpopt.random &= 0xef;
    break;

  /* common tcp && udp */
  case 'x':
    opt.psrc = strtoint (optarg) & PORT_MAX;
    opt.option &= 0xef;
    break;
  case 'X':
    opt.pdst = strtoint (optarg) & PORT_MAX;
    opt.option &= 0xdf;
    break;

    /* tcp */
  case 'e':
    tcpopt.seq = strtoint (optarg);
    tcpopt.random &= 0xfe;
    break;
  case 'a':
    tcpopt.ackseq = strtoint (optarg);
    break;
  case 'S':
    tcpopt.flags |= FLAG_SYN;
    break;
  case 'A':
    tcpopt.flags |= FLAG_ACK;
    break;
  case 'R':
    tcpopt.flags |= FLAG_RST;
    break;
  case 'F':
    tcpopt.flags |= FLAG_FIN;
    break;
  case 'P':
    tcpopt.flags |= FLAG_PSH;
    break;
  case 'U':
    tcpopt.flags |= FLAG_URG;
    break;
  case 'w':
    tcpopt.windows = strtoint (optarg);
    break;
  case 'u':
    tcpopt.ptr = strtoint (optarg);
    break;
  case 'M':
    *(tcpopt.opt) = TCPOPT_MSS;
    sscanf (optarg, "%x", tcpopt.opt + 2);
    buff = *(tcpopt.opt + 3);
    *(tcpopt.opt + 3) = *(tcpopt.opt + 2);
    *(tcpopt.opt + 2) = buff;    
    break;
  case 16:
    *(tcpopt.opt) = TCPOPT_TIMESTAMP;
    break;

    /* recv opt */
  case 'V':
    opt.option |= VERBOSE_RECV;
    break;
	case 'H':
    opt.option |= HEXA_RECV;
    break;
  case 'W':
    opt.option |= NO_RECV;
    break;
        }
    }
  while (c != -1);

  if (argc - optind == 1)
    {
      opt.target_orig = argv[optind];
      ipopt.dst = get_ip (argv[optind]);
      if (ipopt.dst == -1)
        {
          xfree (filename);
          return -1;
        }
    }
  else
    {
      if (!err)
	{
	  error (0, "no target specified!\n", NULL);
	  xfree (filename);
	  return -1;
	}
    }

  if (err == 1)
    usage ();
  else if (err > 1)
    usage_fr ();

  if (opt.protocol == UNKNOW)
    error (1, "protocol unknow!\n", NULL);

  if (opt.protocol == IGMP)
    error (1, "Protocol not implented !! for the next version ??\n", NULL);

  get_data (filename);
  xfree (filename);
  if (get_network_configuration () == -1)
    {
      error (0, "get network info fails.\n", NULL);
      return -1;
    }

  if ((opt.option & VERBOSE_RECV) && (opt.option & HEXA_RECV))
    error (1, "print verbose and hexa ON, specified just 1 mode\n", NULL);

  init_default_opt ();
  return 0;
}

void
init_default_opt (void)
{
  time_t ti;

  if (opt.protocol == ICMP)
    {
      opt.hdrsize = ICMPHDR_SIZE;
      if (icmpopt.type == DEST_UNREACHABLE ||
          icmpopt.type == SRC_QUENCH ||
          icmpopt.type == REDIRECT ||
          icmpopt.type == TIME_EXCEEDED ||
          icmpopt.type == PARAM_UNINTELLIGIBLE)
        {
          opt.hdrsize += IPHDR_SIZE + UDPHDR_SIZE;
          if (!icmpopt.tcp && !icmpopt.udp)
            {
              icmpopt.tcp = 1;
              icmpopt.proto = TCP;
            }

          if (icmpopt.tcp)
            {
              icmpopt.proto = TCP;
              if (!icmpopt.t.tcp.seq)
                icmpopt.t.tcp.seq = get_random_number (DEFAULT);
            }
          else
            {
              icmpopt.proto = UDP;
              if (!icmpopt.t.udp.len)
                icmpopt.t.udp.len = get_random_number (PKTSIZE_MAX);

              if (!icmpopt.t.udp.check)
                icmpopt.t.udp.check = htons (get_random_number (PKTSIZE_MAX));
            }
          if (icmpopt.type == 5 && !icmpopt.router)
            icmpopt.router = ip_create_random ();
        }
      else if (icmpopt.type == TIMESTAMP_REQUEST ||
	       icmpopt.type == TIMESTAMP_REPLY)
	opt.hdrsize += sizeof (struct time_s);
    }

  else if (opt.protocol == UDP)
    opt.hdrsize = UDPHDR_SIZE;

  else if (opt.protocol == TCP)
    {
      opt.hdrsize = TCPHDR_SIZE;
      if (*(tcpopt.opt))
	{
	  if (*(tcpopt.opt) == TCPOPT_MSS)
	    {
	      *(tcpopt.opt + 1) = 4;
	      opt.hdrsize += 4;
	      tcpopt.doff++;
	    }
	  else if (*(tcpopt.opt) == TCPOPT_TIMESTAMP)
	    {
	      *(tcpopt.opt + 1) = 1;
	      *(tcpopt.opt + 2) = 8;
	      *(tcpopt.opt + 3) = 10;
	      ti = get_gmt_timestamp (time (NULL));
	      memcpy (tcpopt.opt + 4, &ti, 4);
	      opt.hdrsize += 12;
	      tcpopt.doff += 3;
	    }
	}
      tcpopt.ackseq = opt.lendata;
    }

  ipopt.lenhdr = IPHDR_SIZE;
  if ((*(ipopt.opt) & 0xff))
    {
      if (*(ipopt.opt) == IPOPT_RR)
	{
	   ipopt.lenopt = 40;
	   *(ipopt.opt + 1) = ipopt.lenopt - 1;
	   *(ipopt.opt + 2) = 4;
	   ipopt.ihl = 15;
	 }
      else
	ipopt.ihl = ((ipopt.lenopt + IPHDR_SIZE) * 8) / 32;
      ipopt.lenhdr += ipopt.lenopt;
    }

  if (opt.protocol == ARP)
    {
      sockopt.sock_mode = SOCK_LL;
      if (!arpopt.sip[0] && !arpopt.sip[1] &&
          !arpopt.sip[2] && !arpopt.sip[3])
        memcpy (arpopt.sip, &ipopt.src, 4);
    
      if (!arpopt.tip[0] && !arpopt.tip[1] &&
          !arpopt.tip[2] && !arpopt.tip[3])
        memcpy (arpopt.tip, &ipopt.dst, 4);
    }


  if (sockopt.sock_mode & SOCK_LL)
    {
      opt.off_ip = ETHHDR_SIZE;
#ifdef __OS_IS_LINUX
      sockopt.init_socket = &linux_eth_socket_open;
      sockopt.send_packet = &linux_eth_send;
#else /* __OS_IS_BSD */
      sockopt.init_socket = &BSD_open_eth_device;
      sockopt.send_packet = &BSD_eth_send;
#endif /* end check OS */
    }
  else
    {
      sockopt.init_socket = &init_socket_in;
      sockopt.send_packet = &send_in;
    }


}   
