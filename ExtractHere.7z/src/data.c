/*
 * \file data.c
 * \brief get data for packet
 * \author Simpp
 */
 /*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
get_data (char *pathfile)
{
  int i, j;

  if (opt.lendata < 1)
    return;

  opt.data = xmalloc ((opt.lendata + 1) * sizeof (char));
  *(opt.data + opt.lendata) = 0;

  if (pathfile)
    {
      if (!read_data_to_file (pathfile))
        return;
      else
        error (0, "get data to file fails.\n", NULL);
    }

  j = 0;
  for (i = 0; i < opt.lendata; i++)
    {
      opt.data[i] = CHAR_LIST[j++];
      if (j == strlen (CHAR_LIST))
        j = 0;
    }
}

int
read_data_to_file (const char *pathfile)
{
  int fd, i, n_read;
  char c;

  fd = open (pathfile, O_RDONLY);
  if (fd == -1)
    {
      error (0, "[open()] file not found.\n");
      return -1;
    }

  for (i = 0; i < opt.lendata; i++)
    {
      n_read = read (fd, &c, sizeof (char));
      switch (n_read)
	{
	case -1:
          close (fd);
          return -1;
	  break;
	case 0:
	  lseek (fd, 0, SEEK_SET);
	  break;
	default:
	  opt.data[i] = c;
	  break;
	}
    }

  close (fd);
  return (n_read != -1) ? 0 : -1;
}
