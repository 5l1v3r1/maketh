/*
 * \file netconfig.c
 * \brief get network configuration, for the default value
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"


int
get_network_configuration (void)
{
#ifdef __OS_IS_BSD
  struct ifaddrs *ifaddr = NULL;
  struct ifaddrs *pifaddr = NULL;
  int i;
#endif /* __OS_IS_BSD */
  struct ifreq ifr;
  struct sockaddr_in *to;
  int socket;

  socket = create_new_socket (AF_INET, SOCK_STREAM, 0);
  if (socket == -1)
    return -1;

  if (!opt.devname[0])
    {
#ifdef __OS_IS_LINUX
      if (!opt.i_device)
	opt.i_device = 2;

      ifr.ifr_ifindex = opt.i_device;
      if (xioctl (socket, SIOCGIFNAME, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
        {
          close (socket);
          return -1;
        }
      strncpy (opt.devname, ifr.ifr_name, NETDEVICE_LEN - 1);
#else /* __OS_IS_BSD */

      if (getifaddrs (&ifaddr) == -1)
	{
	  error (0, "[getifaddrs()] fails\n", NULL);
	  freeifaddrs (ifaddr);
	  close (socket);
	  return -1;
	}

      pifaddr = ifaddr;
      if (opt.i_device)
	{
	  for (i = 0; i != opt.i_device && pifaddr; i++)
	    pifaddr = pifaddr->ifa_next;
   
	  if (!pifaddr)
	    {
	      freeifaddrs (ifaddr);
	      error (0, "Interface number <", opt.i_device, "> not found\n", NULL);
	      return -1;
	    }
	}

      strncpy (opt.devname, pifaddr->ifa_name, NETDEVICE_LEN -1);
      freeifaddrs (ifaddr);
#endif /* end test OS */
      strncpy (ifr.ifr_name, opt.devname, NETDEVICE_LEN - 1);
    }
  else
    strncpy (ifr.ifr_name, opt.devname, NETDEVICE_LEN - 1);

  if (!opt.mtu)
    {
#ifdef __OS_IS_LINUX
      opt.mtu = (xioctl (socket, SIOCGIFMTU, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
	? 980 : ifr.ifr_mtu;
#else /* __OS_IS_BSD */
      opt.mtu = (xioctl (socket, SIOCGIFMTU, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
	? 980 : ifr.ifr_ifru.ifru_mtu;
#endif /* end test OS */
    }

  if (!opt.i_device)
    {
      if (xioctl (socket, SIOCGIFINDEX, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
        {
          close (socket);
          return -1;
        }
#ifdef __OS_IS_LINUX
      opt.i_device = ifr.ifr_ifindex;
#else /* __OS_IS_BSD */
      opt.i_device = ifr.ifr_ifru.ifru_index;
#endif /* end test OS */
    }

  if (!ipopt.src)
    {
      if (xioctl (socket, SIOCGIFADDR, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
        {
          close (socket);
          return -1;
        }
      to = (struct sockaddr_in *)&ifr.ifr_ifru.ifru_addr;
      memcpy (&ipopt.src, &to->sin_addr, sizeof (u32));
    }

  if (opt.protocol == ARP &&
      !arpopt.sha[0] && !arpopt.sha[1] &&
      !arpopt.sha[2] && !arpopt.sha[3] &&
      !arpopt.sha[5] && !arpopt.sha[5])
    {
#ifdef __OS_IS_LINUX
      if (xioctl (socket, SIOCGIFHWADDR, (void *)&ifr, IOCTL_TYPE_IFREQ) == -1)
        {
          close (socket);
          return -1;
        }
      memcpy (arpopt.sha, ifr.ifr_hwaddr.sa_data, 6);
#else /* __OS_IS_BSD */
      struct ifaddrs *p_ifaddr = NULL;
      struct sockaddr_dl *sdp = NULL;

      getifaddrs (&ifaddr);
      p_ifaddr = ifaddr;
      while (p_ifaddr)
	{
	  if (p_ifaddr->ifa_addr->sa_family == AF_LINK)
	    {
	      sdp = (struct sockaddr_dl *) p_ifaddr->ifa_addr;
	      memcpy (arpopt.sha, (char *)&sdp->sdl_data + sdp->sdl_nlen, 6);
	      break;
	    }
	  p_ifaddr = p_ifaddr->ifa_next;
	}

      freeifaddrs (ifaddr);
      p_ifaddr = NULL;
#endif /* end check OS */

      if (!ethopt.src[0] && !ethopt.src[1] &&
          !ethopt.src[2] && !ethopt.src[3] &&
          !ethopt.src[5] && !ethopt.src[5])
        memcpy (ethopt.src, arpopt.sha, 6);
    }

  close (socket);
  return 0;
}

int
xioctl (int fd, int flags, void *buffer, int mode)
{
  int ret;
  struct ifreq *ifr = NULL;
  int *dec = NULL;

  switch (mode)
    {
    case IOCTL_TYPE_IFREQ:
      ifr = buffer;
      ret = ioctl (fd, flags, ifr);
      break;
    default:
      dec = buffer;
      ret = ioctl (fd, flags, dec);
      break;
    }

  if ( ret == -1 )
    perror ("[ioctl()] ");

  return ret;
}
