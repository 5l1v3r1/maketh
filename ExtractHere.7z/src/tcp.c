/*
 * \file tcp.c
 * \brief operation on tcp header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
tcp_make_hdr (char *packet)
{
  struct xtcphdr *tcp = (struct xtcphdr *)packet;
  struct addhdr_s addhdr;
  char buff[PKTSIZE_MAX] = {0};

  tcp->source = (opt.option & PSRC_RANDOM) ?
    htons (get_random_number (PORT_MAX)) :
    htons (opt.psrc);
  tcp->dest = (opt.option & PDST_RANDOM) ?
    htons (get_random_number (PORT_MAX)) :
    htons (opt.pdst);
  tcp->seq = (tcpopt.random & TCPSEQ_RANDOM) ?
    htonl (tcpopt.seq++) :
    htonl (tcpopt.seq);
  tcp->ack_seq = htonl(tcpopt.ackseq);
  tcp->doff = tcpopt.doff;
  tcp->syn = GET_NBIT (tcpopt.flags, 0);
  tcp->ack = GET_NBIT (tcpopt.flags, 1);
  tcp->rst = GET_NBIT (tcpopt.flags, 2);
  tcp->fin = GET_NBIT (tcpopt.flags, 3);
  tcp->psh = GET_NBIT (tcpopt.flags, 4);
  tcp->urg = GET_NBIT (tcpopt.flags, 5);
  tcp->window = htons(tcpopt.windows);
  tcp->urg_ptr = htons(tcpopt.ptr);
  tcp->check = 0;

  memcpy (&addhdr.saddr, &ipopt.src, sizeof (u32));
  memcpy (&addhdr.daddr, &ipopt.dst, sizeof (u32));
  addhdr.useless = htons(0);
  addhdr.protocol = IPPROTO_TCP;
  addhdr.length = htons (opt.lendata);

  memcpy (buff, tcp, TCPHDR_SIZE);
  memcpy (buff + TCPHDR_SIZE, tcpopt.opt, opt.hdrsize - TCPHDR_SIZE);
  memcpy (buff + opt.hdrsize, &addhdr, ADDHDR_SIZE);
  memcpy (buff + opt.hdrsize + ADDHDR_SIZE, packet + opt.hdrsize,
          opt.lendata - opt.hdrsize);

  tcp->check = packet_in_cksum ((unsigned short *)buff,
                                opt.lendata + ADDHDR_SIZE);

  memcpy (packet + TCPHDR_SIZE, tcpopt.opt, opt.hdrsize - TCPHDR_SIZE);
}
