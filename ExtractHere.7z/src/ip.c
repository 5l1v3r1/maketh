/*
 * \file ip.c
 * \brief operation on ip header
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

u32
get_ip (const char *target)
{
  u32 ip;
  struct in_addr *addr = NULL;
  struct hostent *host = NULL;

  host = gethostbyname (target);
  if (!host)
    {
      error (0, "host unknow: ", target, "\n", NULL);
      return -1;
    }

  addr = (struct in_addr *)host->h_addr;
  memcpy (&ip, addr, sizeof (u32));
  return ip;
}

void
ip_make_hdr (char *packet, int sizefrag)
{
  struct xiphdr *ip = (struct xiphdr *)(packet + opt.off_ip);
                    
  ip->ihl = ipopt.ihl;
  ip->version = 4;
  ip->tos = 0;
  ip->id = htons (ipopt.id);
#ifdef __OS_IS_LINUX
  ip->frag_off = htons (ipopt.fragoff);
#else /* __OS_IS_BSD */
  ip->frag_off = ipopt.fragoff;
#endif /* end test OS */
  ip->ttl = ipopt.ttl;

#ifdef __OS_IS_LINUX
  ip->tot_len = htons(sizefrag);
#else /* __OS_IS_BSD */
    ip->tot_len = (sockopt.sock_mode == SOCK_LL) ?
      htons (sizefrag) : sizefrag;
#endif /* end check OS */

  ip->protocol = opt.protocol;
  memcpy (&ip->saddr, &ipopt.src, sizeof (u32));
  memcpy (&ip->daddr, &ipopt.dst, sizeof (u32));
  ip->check = 0;
  if (ipopt.lenopt)
    memcpy (packet + IPHDR_SIZE, ipopt.opt, ipopt.lenopt);
  ip->check = packet_in_cksum ((unsigned short *)ip, ipopt.lenhdr);
}

u32
ip_create_random (void)
{
  u32 ip;

  ip = (ip >> 24) | get_random_number (MAX_IP);
  ip = ((ip >> 24) | (ip << 8)) | get_random_number (MAX_IP);
  ip = ((ip >> 16) | (ip << 16)) | get_random_number (MAX_IP);
  ip = ((ip >> 8) | (ip << 24)) | get_random_number (MAX_IP);

  return ip;
}
/*
u32
ip_create_to_network_mask (u32 mask)
{
  char class;

  



  switch (class)
    {
    case 'A':
      **
	 8 bits reseau
	 24 bist host 
      **
      break;
    case 'B':
      **
	 16 bits reseau
	 16 bits host
      **
      break;
    case 'C':
      **
	24 bits reseau
	8 bits ID
      **
      break;
    }
}

*/

void
set_route (const char *route)
{
  struct in_addr addr;
  const char *proute = route;
  char ip[IPv4SIZE];
  int i;

  *(ipopt.opt) |= IPOPT_COPIED;
  *(ipopt.opt + 2) = 4;
  ipopt.lenopt = 3;

  while (*proute && ipopt.lenopt < 37)
    {
      i = 0;
      clean (ip, IPv4SIZE);
      while (*proute && *proute != ',' && i < IPv4SIZE)
	ip[i++] = *proute++;
      addr.s_addr = inet_addr (ip);
      memcpy (ipopt.opt + ipopt.lenopt, &addr, 4);
      ipopt.lenopt += 4;
      *(ipopt.opt + 2) += 4;
      if (*proute)
	proute++;
    }

  *(ipopt.opt + ipopt.lenopt) = 0x00;
  *(ipopt.opt + 1) = ipopt.lenopt;
  ipopt.lenopt++;
}

char **
get_route (const char *pkt, int off)
{
  u_char *option  = (u_char *) pkt;
  struct in_addr *addr = NULL;
  char **route = NULL;
  int i;

  if (*option != IPOPT_RR || !*(option + 7))
    return NULL;

  i = 1;
  option += 3;
  route = (char **) xmalloc (i * sizeof (char *));
  while (off && *(option + 1) && (*option) != 0)
    {
      addr = (struct in_addr *) option;
      route[i - 1] = xstrdup (inet_ntoa (*addr));
      route = realloc (route, (++i * sizeof (char *)));
      route[i - 1] = NULL;
      option += 4;
      off -= 4;
    }

  return route;
}

void
print_route (char **rroute)
{
  char **prroute = rroute;

  printf ("Option Record Route:\n");
  do
    printf ("\r\t%s\n", *prroute++);
  while (*prroute);
}


void
free_route (char **route)
{
  char **proute = route;

  while (*proute)
    xfree (*proute++);
  xfree (route);
}
