/*
 * \file recv.c
 * \brief recv and check packet
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void *
func_packet_recv (void *a)
{
  struct timeval timeout;
  struct socket_s socket;
  fd_set set_read;
  int n_read, n_current;
  char *packet = NULL;
  
  memset (&stt, 0, sizeof (struct stt_s));
  
#ifdef __OS_IS_LINUX
  linux_eth_socket_open (&socket, ARP);
  socket.sizepkt = PKTSIZE_MAX + 1;
#else /* __OS_IS_BSD */
  BSD_open_eth_device (&socket, 0);
#endif /* end test OS */  

  packet = xmalloc (socket.sizepkt);

  n_current = 1;
  timeout.tv_usec = 0;
  timeout.tv_sec = 1;

  while (ok)
    {
      FD_ZERO (&set_read);
      FD_SET (socket.fd, &set_read);
      if (select (socket.fd + 1, &set_read, NULL, NULL, &timeout) > 0)
	{ 
	  n_read = read (socket.fd, packet, socket.sizepkt);
	  if (n_read == -1)
	    {
	      close (socket.fd);
	      return (void *)-1;
	    }
	  recv_check_packet (packet, n_read, &n_current);
	}
    }

  close (socket.fd);
  return (void *)0;
}

void
recv_check_packet (const char *pkt, int sizepkt, int *n_current)
{
#ifdef __OS_IS_BSD
  struct bpf_hdr *bpf = NULL;
#endif /* __OS_IS_BSD */
  struct xiphdr *ip = NULL;
  struct xicmphdr *icmp = NULL;
  struct xtcphdr *tcp = NULL;
  struct arphdr_s *arp = NULL;
  int offset, off_proto_hdr;
  int off_line_hexa;

  offset = 0;
#ifdef __OS_IS_BSD
  bpf = (struct bpf_hdr *)pkt;
  offset += bpf->bh_hdrlen;
  bpf = NULL;
#endif /* __OS_IS_BSD */

  if (opt.protocol == ARP)
    {
      if (sizepkt < ARPPKT_SIZE)
	return;

      arp = (struct arphdr_s *) (pkt + offset + ETHHDR_SIZE);
      if (memcmp (arp->ar_sip, arpopt.tip, 4))
      	return;

      switch (opt.option & HEXA_RECV)
	{
	case 1:
	  off_line_hexa = print_ethernet_hexa (pkt + offset);
	  print_arp_hexa (arp, &off_line_hexa);
	  break;
	default:
	  print_ethernet (pkt + offset);
	  print_arp (arp);
	  break;
	}

      printf("\n\n");
      stt.recv++;
      return;
    }

  if (sizepkt < (offset + ETHHDR_SIZE + IPHDR_SIZE))
    return;

  offset += ETHHDR_SIZE;
  ip = (struct xiphdr *) (pkt + offset);

  if (ip->saddr != ipopt.dst)
    return;

  if ((opt.protocol == UDP && ip->protocol != ICMP) &&
      ip->protocol != opt.protocol)
    return;









  off_proto_hdr = offset + ((ip->ihl  * 32) / 8);
  if (ip->protocol == UDP || ip->protocol == ICMP)
    {
      if (sizepkt < offset + IPHDR_SIZE + ICMPHDR_SIZE)
	return;
      icmp = (struct xicmphdr *) (pkt + off_proto_hdr);

      if (opt.protocol == UDP && (icmp->type != 3 || icmp->code != 3))
	return;

      if (opt.protocol == ICMP)
	{
	  if (icmpopt.type == ECHO_REQUEST && icmp->type)
	    return;
	  if (icmpopt.type == TIMESTAMP_REQUEST &&
	      icmp->type != TIMESTAMP_REPLY)
	    return;

	  /**
	   * + 84 : parce que ce type de paquet contien l'entete IP
	   * original (20 octets) plus 64 bits de l'entete UDP ou TCP
	   */
	  if ((icmp->type == DEST_UNREACHABLE ||
	       icmp->type == SRC_QUENCH ||
	       icmp->type == REDIRECT) &&
	      sizepkt < (off_proto_hdr + ICMPHDR_SIZE + 84))
	    {
	      error (0, "maybe packet receved malformed\n", NULL);
	      return;
	    }
	  else if ((icmp->type == TIMESTAMP_REQUEST ||
		    icmp->type == TIMESTAMP_REPLY) &&
		   sizepkt < (off_proto_hdr + ICMPHDR_SIZE + sizeof (struct time_s)))
	    {
	      error (0, "maybe packet receved malformed\n", NULL);
	      return;
	    }
	}

      if (opt.option & VERBOSE_RECV)
	{
	  printf ("================== Packet Number: %d ==================\n"
		  "Total size: %d\n", *n_current, sizepkt);
	  print_ethernet (pkt);
	  print_ip_verbose (pkt + offset, offset, sizepkt);
	  print_icmp (pkt + off_proto_hdr);
	}
      else if (opt.option & HEXA_RECV)
	{
	  off_line_hexa = print_ethernet_hexa (pkt);
          print_ip_hexa (pkt + offset, offset, &off_line_hexa);
	  print_icmp_hexa (pkt + off_proto_hdr, sizepkt, &off_line_hexa);
	}
      else
	{
	  print_ip (pkt + offset, offset, sizepkt);
	  print_icmp (pkt + off_proto_hdr);
	}
    }
  else if (ip->protocol == TCP)
    {
      if (sizepkt < offset + IPHDR_SIZE + TCPHDR_SIZE)
	return;

      tcp = (struct xtcphdr *) (pkt + off_proto_hdr);
      if ((!(opt.option & PDST_RANDOM) && ntohs (tcp->source) != opt.pdst) ||
	  (!(opt.option & PSRC_RANDOM) && ntohs (tcp->dest) != opt.psrc))
	return;

      if (opt.option & VERBOSE_RECV)
	{
	  printf ("================== Packet Number: %d ==================\n"
		  "Total size: %d\n", *n_current, sizepkt);
	  print_ethernet (pkt);
	  print_ip_verbose (pkt + offset, offset, sizepkt);
	  print_tcp_verbose (pkt + off_proto_hdr);
	}
      else if (opt.option & HEXA_RECV)
	{
	  off_line_hexa = print_ethernet_hexa (pkt);
	  print_ip_hexa (pkt + offset, offset, &off_line_hexa);
	  print_tcp_hexa (pkt + off_proto_hdr, &off_line_hexa);
	}
      else
	{
	  print_ip (pkt + offset, offset, sizepkt);
	  print_tcp (pkt + off_proto_hdr, sizepkt);
	}
    }

  stt.recv++;
  *n_current += 1;
  printf ("\n\n");
  return;
}
