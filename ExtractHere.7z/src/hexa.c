/*
 * \file hexa.c
 * \brief dump packet on hexadecimal
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

void
print_hexa (size_t size, unsigned int octets, int *newline)
{
  char str_hexa[10] = {0};
  int n_write, i;

  switch (size)
    {
    case 1:
      n_write = snprintf (str_hexa, sizeof (str_hexa) - 1, "%02x", octets);
      break;
    case 2:
      n_write = snprintf (str_hexa, sizeof (str_hexa) - 1, "%04x", octets);
      break;
    case 4:
      n_write = snprintf (str_hexa, sizeof (str_hexa) - 1, "%08x", octets);
      break;
    }

  for (i = 0; i < n_write; i += 2, *newline += 1)
    {
      if (!(*newline % 16))
	print_new_line (*newline);
      printf ("%c%c ", str_hexa[i], str_hexa[i + 1]);
    }
}

void
print_new_line (int current)
{
  int i;
  struct print_hexa_index_s index[] =
    {
      {0, "0x0000"},
      {16, "\n0x0010"},
      {32, "\n0x0020"},
      {48, "\n0x0030"},
      {64, "\n0x0040"},
      {80, "\n0x0050"},
      {96, "\n0x0060"},
      {112, "\n0x0070"},
      {128, "\n0x0080"},
      {144, "\n0x0090"}
    };

  for (i = 0; i < SIZE_TAB_HEXA(sizeof (index)); i++)
    {
      if (current == index[i].nb_line)
	{
	  printf ("%s\r\t", index[i].text);
	  return;
	}
    }
}
