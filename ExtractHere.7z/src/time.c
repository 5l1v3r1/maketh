/*
 * \file time.c
 * \brief time options
 * \author Simpp
 */
/*
 *    This file is part of Maketh.
 *
 *  Maketh is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Maketh is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Maketh.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "maketh.h"

time_t
get_gmt_timestamp (time_t timestamp)
{
  struct tm *t;

  t = gmtime (&timestamp);
  return mktime (t);
}

time_t
get_icmp_timestamp (time_t timestamp)
{
  struct tm *t;
  u_char tt[4];
  time_t ttt;

  t = gmtime (&timestamp);
  tt[3] = t->tm_hour;
  tt[2] = t->tm_min;
  tt[1] = t->tm_sec;
  ttt = 0;
  memcpy (&ttt, tt, 4);

  return htonl(ttt);
}

int
conver_usec (int usec)
{
  return usec * 1000;
}

int
get_timeout (char *strtime)
{
  int buff;

  if (strlen (strtime) == 1 && *strtime == '0')
    return 0;

  if (strchr (strtime, 's'))
    {
      buff = strcspn (strtime, "s");
      *(strtime + buff)  = '\0';

      opt.option &= 0x7f;
      opt.option |= SEC;

      return strtoint (strtime);
    }

  opt.option &= 0xbf;
  opt.option |= USEC;
  buff = strtoint (strtime);

  return conver_usec (buff);
}
